from .stats import *

# this file is invoked when an application imports this package with the following command
# import celtic

print('loading celtic.stats module __init__.py')
