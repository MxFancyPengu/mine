from .plots import *

print('loading celtic.viz module __init__.py')
